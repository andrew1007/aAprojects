
  def method(name, *arg, &block)
    #i=0
    xml = ""
    input = arg.first
    puts input.class
    if input.nil?
      xml << empty_tag(name)
    elsif input.class_is_str
      xml << str_arg(name, input)
    elsif input.class_is_hash
      xml << hash_arg(name, input)
    end

    #if block_given?
    #  xml.add_indent
    #  xml << block.call
  #    xml.remove_indent
  #  end
    xml
  end

  def str_arg(name, arg)
    "<#{name}>#{arg}</#{name}>"
  end

  def hash_arg(name, hash)
    key = hash.keys[0].to_s
    values = hash.values[0].to_s
    "<#{name} #{key}=\"#{values}\"/>"
  end

  def empty_tag(name)
    "<#{name}/>"
  end

  def class_is_str
    self.class == String
  end

  def class_is_hash
    self.class == Hash
  end

  def add_space(str)
    str << "\n"
  end

  def add_indent
    self << "  " * @indent_counter
  end

  def remove_indent
    @indent_counter -= 1 if @indent
  end

 method("yes","dogs")
 method("hello",:name=>"dolly")
