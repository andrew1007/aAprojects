# chunk an array into nested arrays of length n
def chunk(array, n)
  chunks = []
  until array.length < 1
    chunks << array[0..n - 1]
    array.shift(n)
  end
  chunks
end

puts "---------chunk-------"
puts chunk([1, 8, 9, 4, "hey", "there"], 2) == [[1, 8], [9, 4], ["hey", "there"]]
puts chunk([10, 9, 8, 7, 6, 5, 4], 3) == [[10, 9, 8], [7, 6, 5], [4]]

# Translate into pig-latin! First consonants go to the end of a word. End with "ay"
def pig_latin(sentence)
  sen = []
  arr = sentence.split(" ")
  vowels = ["a", "e", "i", "o", "u"]
  arr.each do |word|
    pig_latin_end = []
    word_arr = word.split("")
      i = 0
      pig_end = []
      until vowels.include?(word_arr[i])
        pig_end << word_arr[i]
        i += 1
      end
      word_arr.shift(pig_end.length)
      new_word = word_arr + pig_end + ["ay"]
      sen << new_word.join("")
  end
  sen.join(" ")
end

puts "---------pig latin-------"
puts pig_latin("i speak pig latin") == "iay eakspay igpay atinlay"
puts pig_latin("throw me an aardvark") == "owthray emay anay aardvarkay"

# Remove the nth letter of the string
def remove_nth_letter(string, n)
  string[n] = ""
  string
end

puts "---------remove nth letter-------"
puts remove_nth_letter("helloworld", 5) == "helloorld"
puts remove_nth_letter("helloworld", -3) == "hellowold"

# Boolean function: check if short_string is a substring of long_string
def substring?(long_string, short_string)
  long_string.include?(short_string)
end

puts "---------substring-------"
puts substring?("thisisaverylongstring", "sisa") == true
puts substring?("thisisaverylongstring", "ting") == false
puts substring?("whatifikeptontypingforever", "ik") == true

# count the number of times that two adjacent numbers in an array add up to n.
# You cannot reuse a number. So count_adjacent_sums([1, 5, 1], 6) => 1

def count_adjacent_sums(array, n)
  counter = 0
  until array.length <= 1
    if array[0] + array [1] == n
      counter += 1
      array.shift(2)
    else
      array.shift(1)
    end
  end
  counter
end

puts "---------count adjacent sums-------"
puts count_adjacent_sums([7, 2, 4, 6, 8, 10], 7) == 0
puts count_adjacent_sums([6, 7, 11, 2, 5, 10, 3], 13) == 3
puts count_adjacent_sums([1, 9, 1, 8, 2, 10], 10) == 2

# update the older inventory with the newer inventory. Add any new items to the
# hash and replace the values for items that already exist.

def inventory_hash(older, newer)
  newer.each do |key, value|
    older[key] = value
  end
  older
end

puts "---------inventory hash-------"
march = {rubies: 10, emeralds: 14, diamonds: 2}
april = {emeralds: 27, moonstones: 5}
puts inventory_hash(march, april) == {rubies: 10, emeralds: 27, diamonds: 2, moonstones: 5}

# Now, alphabetical order matters in your inventory. Insert new inventory items into
# your array in the appropriate place
def inventory_array(older, newer)
  old_hash = older.to_h
  new_hash = newer.to_h
  new_hash.each do |key, value|
    old_hash[key] = value
  end
  full_inv = old_hash.to_a
  full_inv.sort_by {|name, num| name}
end

[['rubies', 10], ['diamonds', 2], ['emeralds', 14]].sort_by {|name, num| name}
puts "---------inventory array-------"
march_array = [['diamonds', 2], ['emeralds', 14], ['rubies', 10]]
april_array = [['emeralds', 27], ['moonstones', 5]]
puts inventory_array(march_array, april_array) == [['diamonds', 2], ['emeralds', 27], ['moonstones', 5], ['rubies', 10]]
