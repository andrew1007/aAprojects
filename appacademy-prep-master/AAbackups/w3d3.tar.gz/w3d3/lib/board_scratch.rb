
  def constants
    @alphabet_coordinates = ("A".."J").to_a
    @num_hash = Hash[(@alphabet_coordinates).zip((0..9).to_a)]
  end

  def board
    num_board = []
    alphabet_coordinates = ("A".."J").to_a
    row = (1..10).to_a

    10.times do
      num_board << row
    end

    board=[]
    j=0
    num_board.each do |row|
      board << row.map {|i| i = i.to_s + alphabet_coordinates[j]}
      j+=1
    end
    board
  end

def random_point
  alphabet_coordinates = ("A".."J").to_a
  row = (1..10).to_a
  random = row.sample.to_s + alphabet_coordinates.sample
  end
