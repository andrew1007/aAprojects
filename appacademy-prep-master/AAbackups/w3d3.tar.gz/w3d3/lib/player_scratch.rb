
class HumanPlayer
  attr_accessor :board, :ships

  def initialize
    @board = Board.new.board
    @ships = Board.new.ship_placements
  end

  def human_guess
    ship_coords = @ships.values.flatten
    puts "guess a point"
    guess = gets.chomp
    if ship_coords.include? (guess)
      mark_as_hit_in_ship_hash (guess)
      mark_as_hit_on_board (guess)
    else
      return "invalid move"
    end
  end

  def game
    human_guess
    if all_ships_hit then return "you win" end
      @board
  end

  def all_ships_hit
    @ships.values.flatten.uniq == ["hit"]
  end

  def mark_as_hit_in_ship_hash (guess)
    @ships.each do |point|
      coords= point[1]
      coords.map! {|i| (i == guess)? i = "hit" : i}
    end
  end

  def mark_as_hit_on_board (guess)
    @board.each do |row|
      row.map! {|i| (i == guess)? i = "hit" : i}
    end
  end
end
