class Code
  attr_accessor :PEGS, :pegs

  PEGS = Hash.new(0)
  VALID_COLORS = ["R", "G", "B", "Y", "O", "P"]

  def initialize(arr)
    @pegs = arr
  end

  def self.random
    code = []
    4.times do
      code << VALID_COLORS.sample
    end
    Code.new(code)
  end

  def self.parse(guess)
    guess.upcase!
    guess_arr = guess.split("")
    guess_arr.each do |color|
      raise "parse error" if !VALID_COLORS.include?(color)
    end
    Code.new(guess_arr)
  end

  def [](i)
    @pegs[i]
  end

  def exact_matches(guess_arr)
    matches = 0
    @pegs.each_with_index do |color, index|
      matches += 1 if color == guess_arr[index]
    end
    matches
  end

  def near_matches(guess)
    near_match = 0
    guess_arr = guess.pegs
    near_arr = []
    guess_arr.each_with_index do |color, index|
      if self.pegs.include?(color) && color != self.pegs[index] \
        && !near_arr.include?(color)
        near_match += 1
        near_arr << color
      end
    end
    near_match
  end

  def ==(code)
    return false if code.class != Code
    self.pegs == code.pegs
  end
end

class Game
  attr_accessor :secret_code

  def initialize(code = Code.random)
    @secret_code = code
  end

  def get_guess
      Code.parse(gets.chomp)
  end

  def display_matches(guess)
    exact_matches = @secret_code.exact_matches(guess)
    near_matches = @secret_code.near_matches(guess)

    puts "You got #{exact_matches} exact matches!"
    puts "You got #{near_matches} near matches!"
  end

end
