## Create the hello function
def hello
  "Hello!"
end

def greet(who)
  "Hello, #{who}!"
end
