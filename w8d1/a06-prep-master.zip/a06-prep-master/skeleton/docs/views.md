# View Wireframes

## PostIndex

![alt tag][post_index]

[post_index]: ./wireframes/post_index.png
