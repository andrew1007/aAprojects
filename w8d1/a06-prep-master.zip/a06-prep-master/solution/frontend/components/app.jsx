import React from 'react';

const App = ({ children }) => (
  <div>
    <h1>A06</h1>
    { children }
  </div>
);

export default App;
